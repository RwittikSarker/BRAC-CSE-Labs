input1 = open("input2_3.txt","r")
output1 = open("output2_3.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
m = int(list1[1])
graph = {}
for i in range(1,n+1):
  graph[i] = []
for i in range(m):
  list2 = input1.readline().split(" ")
  graph[int(list2[0])].append(((int(list2[1])),(int(list2[2]))))
list2 = input1.readline().split(" ")
s = int(list2[0])
t = int(list2[1])

def dijkstra(g,n,s):
  dist = [float('inf')]*(n+1)
  dist[s] = 0
  visited = []
  priority_q = [(s,0)]
  while len(priority_q) > 0:
    priority_q.sort(key = lambda x:x[1])
    temp = priority_q.pop(0)
    current = temp[0]
    if current in visited:
      continue
    visited.append(current)
    for neighbor in g[current]:
      tent_dist = dist[current] + neighbor[1]
      if tent_dist < dist[neighbor[0]]:
        dist[neighbor[0]] = tent_dist
        priority_q.append((neighbor[0],tent_dist))
  dist.pop(0)  
  return dist

alice = dijkstra(graph,n,s)
bob = dijkstra(graph,n,t)

min_time = float('inf')
meeting_node = -1
for node in range(1,n+1):
    if alice[node-1] != float('inf') and bob[node-1] != float('inf'):
        total_time = max(alice[node-1], bob[node-1])
        if total_time < min_time:
            min_time = total_time
            meeting_node = node

if meeting_node == -1:
        print("Impossible", file=output1)
else:
        print("Time", min_time, file=output1)
        print("Node", meeting_node, file=output1)
input1.close()
output1.close()