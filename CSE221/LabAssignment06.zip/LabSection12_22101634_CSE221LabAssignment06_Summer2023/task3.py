input1 = open("input3_2.txt","r")
output1 = open("output3_2.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
m = int(list1[1])
graph = {}
for i in range(1,n+1):
  graph[i] = []
for i in range(m):
  list2 = input1.readline().split(" ")
  graph[int(list2[0])].append(((int(list2[1])),(int(list2[2]))))


def dijkstra(g,s,n):
  dist = [float('inf')]*(n+1)
  dist[s] = 0
  visited = []
  priority_q = [(s,0)]
  while len(priority_q) > 0:
    priority_q.sort(key = lambda x:x[1])
    temp = priority_q.pop(0)
    current = temp[0]
    if current in visited:
      continue
    visited.append(current)
    for neighbor in g[current]:
      danger_lvl = max(dist[current], neighbor[1])
      if danger_lvl < dist[neighbor[0]]:
        dist[neighbor[0]] = danger_lvl
        priority_q.append((neighbor[0],danger_lvl))  
  return dist[n]

min_danger_level = dijkstra(graph,1,n)
if min_danger_level == float('inf'):
        print("Impossible", file=output1)
else:
        print(min_danger_level, file=output1)
input1.close()
output1.close()