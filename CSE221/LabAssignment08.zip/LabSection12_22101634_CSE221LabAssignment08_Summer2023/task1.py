input1 = open("input1_2.txt","r")
output1 = open("output1_2.txt","w")
list1 = input1.readline().split(" ")
result = int(list1[0])
m = int(list1[1])
roads = []

for i in range(m):
  temp = [int(j) for j in input1.readline().split(" ")]
  roads.append((temp[0],temp[1],temp[2]))
roads.sort(key = lambda x:x[2])

def find_parent(parent,u):
  if parent[u] != u:
    parent[u] = find_parent(parent,parent[u])
  return parent[u]

def kruskal(graph,n):
  parent = [0]*(n+1)
  for i in range(n+1):
    parent[i] = i
  cost = 0
  for u,v,w in graph:
    parent_u = find_parent(parent,u)
    parent_v = find_parent(parent,v)
    if parent_u != parent_v:
      parent[parent_v] = parent_u
      cost += w
  return cost

min_cost = kruskal(roads,result)
output1.writelines(str(min_cost))
input1.close()
output1.close()