input1 = open("input3_2.txt","r")
output1 = open("output3_2.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
result = int(list1[1])
array = [int(j) for j in input1.readline().split(" ")]

def coin_check(result, array):
    list1 = [result+1]*(result+1)
    list1[0] = 0
    for i in range(1,result+1):
        for j in array:
            if i - j >= 0:
                list1[i] = min(list1[i],list1[i-j] + 1)
    return list1[result] if list1[result] != result+1 else -1

num_coin = coin_check(result,array)
output1.writelines(str(num_coin))
input1.close()
output1.close()