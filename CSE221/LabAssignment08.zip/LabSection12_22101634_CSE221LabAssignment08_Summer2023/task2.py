input1 = open("input2_4.txt","r")
output1 = open("output2_4.txt","w")
result = int(input1.readline())
list1 = [0]*(result+1)

def count(array,n):
    array[0] = 1
    array[1] = 1

    for i in range(2,n+1):
        array[i] = array[i-1] + array[i-2]
    return array[n]

count_step = count(list1,result)
output1.writelines(str(count_step))
input1.close()
output1.close()