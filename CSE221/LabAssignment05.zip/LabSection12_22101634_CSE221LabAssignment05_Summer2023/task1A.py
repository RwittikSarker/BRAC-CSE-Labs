input1 = open("input1_3.txt","r")
output1 = open("output1A_3.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
m = int(list1[1])
graph = {}
for i in range(1,n+1):
  graph[i] = []
for i in range(m):
  list2 = input1.readline().split(" ")
  graph[int(list2[0])].append(int(list2[1]))
list3 = []
list4 = []
for v in graph.values():
  list3.extend(v)
for u in graph.keys():
  if u not in list3:
    list4.append(u)
visited = []

def dfs(visited,graph,parent):
  if type(parent) == list:
    for i in parent:
      n = str(i) + " "
      output1.writelines(n)
      visited.append(i)
      for j in graph[i]:
        dfs(visited,graph,j)
  else:
    if parent not in visited:
      n = str(parent) + " "
      output1.writelines(n)
      visited.append(parent)
      for j in graph[parent]:
        dfs(visited,graph,j)

dfs(visited,graph,list4)
input1.close()
output1.close()