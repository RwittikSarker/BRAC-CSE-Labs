input1 = open("input2_2.txt","r")
output1 = open("output2_2.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
m = int(list1[1])
graph = {}
indeg = [0]*(n+1)
for i in range(1,n+1):
  graph[i] = []
for i in range(m):
  list2 = input1.readline().split(" ")
  graph[int(list2[0])].append(int(list2[1]))
  indeg[int(list2[1])] = indeg[int(list2[1])]+1

def lexSeq(graph,indeg,n):
    queue = []
    count = 0
    res = ""

    for i in range(1, len(indeg)):
        if indeg[i] == 0:
            queue.append(i)
    
    while queue:
        smol = min(queue)
        idx = queue.index(smol)
        u = queue.pop(idx)
        res += str(u) + " "
        count += 1
        for v in graph[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                queue.append(v)
    if count != n:
        output1.writelines("IMPOSSIBLE")
    else:
        output1.writelines(res)
lexSeq(graph,indeg,n)
input1.close()
output1.close()