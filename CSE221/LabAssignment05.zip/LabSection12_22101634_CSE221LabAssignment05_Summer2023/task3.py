input1 = open("input3_2.txt","r")
output1 = open("output3_2.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
m = int(list1[1])
graph = {}
rev_graph = {}
for i in range(1,n+1):
  graph[i] = []
  rev_graph[i] = []

for i in range(0,m):
  list2 = input1.readline().split(" ")         
  graph[int(list2[0])].append(int(list2[1]))
  rev_graph[int(list2[1])].append(int(list2[0]))

def dfs1(node, graph, visited, stack):
    visited[node] = True
    for neighbor in graph[node]:
        if not visited[neighbor]:
            dfs1(neighbor, graph, visited, stack)
    stack.append(node)

def dfs2(node, graph, visited, component):
    visited[node] = True
    component.append(node)
    for neighbor in graph[node]:
        if not visited[neighbor]:
            dfs2(neighbor, graph, visited, component)

def find_scc(graph):
    visited_1 = [False] * (n + 1)
    stack = []
    for i in range(1, n + 1):
        if not visited_1[i]:
            dfs1(i, graph, visited_1, stack)

    visited_2 = [False] * (n + 1)
    scc = []
    while stack:
        node = stack.pop()
        if not visited_2[node]:
            component = []
            dfs2(node, rev_graph, visited_2, component)
            scc.append(component)

    return scc
scc = find_scc(graph)

for i in scc:
    for j in i:
        output1.writelines(f"{str(j)} ")
    output1.writelines("\n")
input1.close()
output1.close()
