input1 = open("input1_3.txt","r")
output1 = open("output1B_3.txt","w")
list1 = input1.readline().split(" ")
n = int(list1[0])
m = int(list1[1])
graph = {}
for i in range(1,n+1):
  graph[i] = []
for i in range(m):
  list2 = input1.readline().split(" ")
  graph[int(list2[0])].append(int(list2[1]))
list3 = []
list4 = []
for v in graph.values():
  list3.extend(v)
for u in graph.keys():
  if u not in list3:
    list4.append(u)
list3 = []
for u,v in graph.items():
  if u not in list3:
    list3.append(u)
  for i in v:
    if i not in list3:
      list3.append(i)

def bfs(graph,parent,nodes):
  visited = []
  queue = []
  visited.extend(parent)
  queue.extend(parent)
  ans = []

  while queue != []:
    m = queue.pop(0)
    ans.append(m)

    for i in graph[m]:
      if i not in visited:
        visited.append(i)
        queue.append(i)
  flag = True
  for i in list3:
    if i not in ans:
      output1.writelines("IMPOSSIBLE")
      flag = False
      break
  for j in ans:
    if flag == False:
      break
    n = str(j) + " "
    output1.writelines(n)

bfs(graph,list4,list3)
input1.close()
output1.close()