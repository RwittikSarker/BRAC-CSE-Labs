input1 = open("input2_4.txt","r")
output1 = open("output2_4.txt","w")
temp = [int(j) for j in input1.readline().split(" ")]
n = temp[0]
m = temp[1]
array = [[] for _ in range(n)]

for i in range(n):
  temp = [int(j) for j in input1.readline().split(" ")]
  array[i].append(temp[0])
  array[i].append(temp[1])
array.sort(key = lambda x:x[1])
count = 0
assigned=[0]*m 
for task in array:
    for i in range(m):
        if assigned[i]<=task[0]:
            assigned[i]=task[1] 
            count+=1
            break
output1.writelines(str(count))
input1.close()
output1.close()