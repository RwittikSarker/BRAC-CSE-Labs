input1 = open("input1_3.txt","r")
output1 = open("output1_3.txt","w")
n = int(input1.readline())
array = [[] for _ in range(n)]

for i in range(n):
  temp = [int(j) for j in input1.readline().split(" ")]
  array[i].append(temp[0])
  array[i].append(temp[1])
array.sort(key = lambda x:x[1])
count = 0
str1 = ""

for i in range(n):
  if count == 0:
    str1 += str(array[i][0]) + " " + str(array[i][1])
    str1 += "\n"
    count += 1
    temp = array[i][1]
  else:
    if array[i][0] < temp:
      continue
    else:
      str1 += str(array[i][0]) + " " + str(array[i][1])
      str1 += "\n"
      count += 1
      temp = array[i][1]
      
output1.writelines(str(count))
output1.writelines("\n")
output1.writelines(str1)
input1.close()
output1.close()