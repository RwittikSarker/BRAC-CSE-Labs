input1 = open("input3_2.txt","r")
output1 = open("output3_2.txt","w")
temp1 = [int(j) for j in input1.readline().split(" ")]
n = temp1[0]
k = temp1[1]
parent = [None]*(n+1)
array = [[i] for i in range(n+1)]

for i in range(len(parent)):
   parent[i] = i
adjlist = [0]*(n+1)
str1 = ""

for i in range(k):
   temp2 = [int(j) for j in input1.readline().split(" ")]
   if parent[temp2[0]] == parent[temp2[1]]:
      str1 += str(len(array[parent[temp2[0]]]))
      str1 += "\n"
      continue
   elif parent[temp2[0]] == temp2[0]:
      if parent[temp2[1]] == temp2[1]:
         parent[temp2[1]] = temp2[0]
         adjlist[temp2[0]] = True
         array[temp2[0]].append(temp2[1])
         str1 += str(len(array[temp2[0]]))
         str1 += "\n"
      else:
         parent[temp2[0]] = parent[temp2[1]]
         array[parent[temp2[1]]].append(temp2[0])
         str1 += str(len(array[parent[temp2[1]]]))
         str1 += "\n"
   else:
      if (parent[temp2[1]] == temp2[1]) and (adjlist[temp2[1]] == 0):
         parent[temp2[1]] = parent[temp2[0]]
         array[parent[temp2[0]]].append(temp2[1])
         str1 += str(len(array[parent[temp2[0]]]))
         str1 += "\n"
      else:
         array[parent[temp2[0]]].extend(array[parent[temp2[1]]])
         parent[parent[temp2[1]]] = parent[temp2[0]]
         str1 += str(len(array[parent[temp2[0]]]))
         str1 += "\n"
         
output1.writelines(str1)
input1.close()
output1.close()